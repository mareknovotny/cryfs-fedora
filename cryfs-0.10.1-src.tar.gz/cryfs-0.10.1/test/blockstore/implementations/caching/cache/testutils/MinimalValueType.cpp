#include "MinimalValueType.h"

std::atomic<int> MinimalValueType::instances(0);
