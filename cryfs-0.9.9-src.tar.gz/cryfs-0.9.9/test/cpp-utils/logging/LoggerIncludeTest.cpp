#include "cpp-utils/logging/Logger.h"

// Test the header can be included without needing additional dependencies
