#include "cpp-utils/io/Console.h"

// Test the header can be included without needing additional dependencies
