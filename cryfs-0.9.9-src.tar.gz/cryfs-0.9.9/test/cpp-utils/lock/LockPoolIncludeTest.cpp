#include "cpp-utils/lock/LockPool.h"

// Test the header can be included without needing additional dependencies
