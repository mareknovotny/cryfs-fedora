#include "cpp-utils/lock/MutexPoolLock.h"

// Test the header can be included without needing additional dependencies
