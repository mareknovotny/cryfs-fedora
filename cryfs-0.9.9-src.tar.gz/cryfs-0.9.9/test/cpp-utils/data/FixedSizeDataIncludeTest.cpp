#include "cpp-utils/data/FixedSizeData.h"

// Test the header can be included without needing additional dependencies