#include "cpp-utils/assert/backtrace.h"

// Test the header can be included without needing additional dependencies

