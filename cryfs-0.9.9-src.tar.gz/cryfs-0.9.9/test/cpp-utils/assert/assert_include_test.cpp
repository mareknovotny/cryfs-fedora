#include "cpp-utils/assert/assert.h"

// Test the header can be included without needing additional dependencies
