#include "cpp-utils/pointer/unique_ref_boost_optional_gtest_workaround.h"

// Test the header can be included without needing additional dependencies
