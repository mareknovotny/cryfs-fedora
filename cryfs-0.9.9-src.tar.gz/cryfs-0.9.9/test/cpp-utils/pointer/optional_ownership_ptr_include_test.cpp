#include "cpp-utils/pointer/optional_ownership_ptr.h"

// Test the header can be included without needing additional dependencies
