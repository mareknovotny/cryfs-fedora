#include "cpp-utils/macros.h"

// Test that macros.h can be included without needing additional dependencies
