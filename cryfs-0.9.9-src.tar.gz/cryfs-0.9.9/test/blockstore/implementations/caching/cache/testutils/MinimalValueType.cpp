#include "MinimalValueType.h"

int MinimalValueType::instances = 0;
