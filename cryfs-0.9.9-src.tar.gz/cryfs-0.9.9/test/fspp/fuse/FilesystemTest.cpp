/*
 * Tests that the header can be included without needing additional header includes as dependencies.
 */
#include "fspp/fuse/Filesystem.h"
