#include "parallelaccessstore/ParallelAccessBaseStore.h"

// Test that ParallelAccessBaseStore.h can be included without errors
