#include "MinimalKeyType.h"

int MinimalKeyType::instances = 0;
