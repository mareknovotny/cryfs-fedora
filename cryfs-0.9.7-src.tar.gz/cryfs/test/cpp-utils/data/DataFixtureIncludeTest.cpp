#include "cpp-utils/data/DataFixture.h"

// Test the header can be included without needing additional dependencies