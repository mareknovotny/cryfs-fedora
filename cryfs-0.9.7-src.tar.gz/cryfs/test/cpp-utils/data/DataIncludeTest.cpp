#include "cpp-utils/data/Data.h"

// Test the header can be included without needing additional dependencies