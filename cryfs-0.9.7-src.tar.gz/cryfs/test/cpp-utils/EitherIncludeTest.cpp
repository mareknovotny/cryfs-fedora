#include "cpp-utils/either.h"

//Test that either can be included without needing additional dependencies
