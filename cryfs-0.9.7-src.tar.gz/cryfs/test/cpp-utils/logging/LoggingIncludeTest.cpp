#include "cpp-utils/logging/logging.h"

// Test the header can be included without needing additional dependencies
