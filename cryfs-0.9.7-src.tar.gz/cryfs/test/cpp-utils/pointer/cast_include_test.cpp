#include "cpp-utils/pointer/cast.h"

// Test the header can be included without needing additional dependencies
