#pragma once
#ifndef GITVERSION_VERSIONSTRING_H
#define GITVERSION_VERSIONSTRING_H

#include <string>

namespace gitversion {
    const std::string &VersionString();
}

#endif
