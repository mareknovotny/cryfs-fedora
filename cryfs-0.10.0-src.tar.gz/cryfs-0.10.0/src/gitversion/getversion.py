#!/usr/bin/env python

import versioneer

print(versioneer.get_version())
