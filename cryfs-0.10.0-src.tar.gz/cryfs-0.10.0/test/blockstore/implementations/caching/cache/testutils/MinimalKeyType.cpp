#include "MinimalKeyType.h"

std::atomic<int> MinimalKeyType::instances(0);
