#include "FsBlobView.h"

namespace cryfs {
    constexpr uint16_t FsBlobView::FORMAT_VERSION_HEADER;
}