#include "Random.h"

namespace cpputils {
    std::mutex Random::_mutex;
}