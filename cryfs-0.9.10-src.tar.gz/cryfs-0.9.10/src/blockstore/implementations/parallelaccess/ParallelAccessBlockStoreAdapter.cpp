#include "ParallelAccessBlockStoreAdapter.h"
