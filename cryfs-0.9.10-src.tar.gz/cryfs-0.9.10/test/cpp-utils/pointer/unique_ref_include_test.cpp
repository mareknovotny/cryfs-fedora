#include "cpp-utils/pointer/unique_ref.h"

// Test the header can be included without needing additional dependencies
