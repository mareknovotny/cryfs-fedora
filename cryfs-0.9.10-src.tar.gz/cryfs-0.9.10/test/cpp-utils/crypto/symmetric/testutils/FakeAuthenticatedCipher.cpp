#include "FakeAuthenticatedCipher.h"

namespace cpputils {
    constexpr unsigned int FakeKey::BINARY_LENGTH;
}
