#include "CopyableMovableValueType.h"

int CopyableMovableValueType::numCopyConstructorCalled = 0;
