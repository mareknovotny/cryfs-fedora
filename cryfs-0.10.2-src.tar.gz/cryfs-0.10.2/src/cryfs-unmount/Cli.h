#pragma once
#ifndef MESSMER_CRYFSUNMOUNT_CLI_H
#define MESSMER_CRYFSUNMOUNT_CLI_H

namespace cryfs_unmount {

class Cli final {
public:
    void main(int argc, const char **argv);
};

}

#endif
