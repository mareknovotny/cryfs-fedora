#include "PseudoRandomPool.h"

namespace cpputils {
    constexpr size_t PseudoRandomPool::MIN_BUFFER_SIZE;
    constexpr size_t PseudoRandomPool::MAX_BUFFER_SIZE;
}